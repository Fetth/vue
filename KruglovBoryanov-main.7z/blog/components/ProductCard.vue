<template>

    <v-card :elevation="10"  width="300px" height="410px">
        
        <v-img :src="product.image" class="img"></v-img>

        <v-card-title>{{ product.title }}</v-card-title>

        <v-card-text>{{ product.made }}</v-card-text>
        <v-card-subtitle>{{ product.price }} руб.</v-card-subtitle>

        <v-card-actions>
            <v-btn variant="flat" color="indigo" @click="basketStore.add(this.product)">
                Купить
            </v-btn>
            <!-- <v-btn flat to="/more">
                    Подробнее
            </v-btn> -->
        </v-card-actions>
  </v-card>

</template>

<script setup>

const { product } = defineProps(['product'])
const basketStore = useBasketStore();

</script>

<style scoped>

.img{
    width: 300px;
    height: 250px;

}
</style>
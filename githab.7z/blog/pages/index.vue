<template>
       <v-container>
        <v-row>
            <v-col>
                <v-row>
                    <v-col v-for="product in products" :key="product.id" sm="6" md="4">
                        <ProductCard :product="product" />
                    </v-col>
                </v-row>
            </v-col>
        </v-row>
    </v-container>
    <p>Всего товаров {{useBasketStore.length}} </p>

</template>

<script setup>
import ProductCard from '~~/components/ProductCard.vue'

const { data: products } = await useFetch('http://127.0.0.1:8000/api/v1/')


</script>

<style>
main {
    margin-left: 20px;
}
.container{
  padding-left: 50px;
}
</style>
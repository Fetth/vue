<template>
<NuxtLayout></NuxtLayout>
</template>

<script setup>
</script>

<style>

</style>
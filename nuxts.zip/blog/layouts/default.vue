<template>
  <v-app>


  <v-toolbar-items>
    <v-btn flat to="/" nuxt> Home </v-btn>
 </v-toolbar-items>

</v-app>
</template>

<script>

</script>

<style scoped>
.container {
  background-color: gray;
  height: 60px;
}
</style>
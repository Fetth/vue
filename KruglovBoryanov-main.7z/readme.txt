python -m venv venv

venv\Scripts\activate

pip install django==3.2

pip install djangorestframework

pip install django-cors-headers

npm i


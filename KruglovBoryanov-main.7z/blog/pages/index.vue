<template>
       <v-container>
            <v-col>
                <v-row>
                    <v-col v-for="product in products" :key="product.id" sm="6" md="3">
                        <ProductCard :product="product" />
                    </v-col>
                </v-row>
            </v-col>
    </v-container>


</template>

<script setup>
import ProductCard from '~~/components/ProductCard.vue'

const { data: products } = await useFetch('http://127.0.0.1:8000/api/v1/')


</script>

<style setup>
main{
    color: black;
}

.card{
    width: 300px;
    height: 410px;
}
</style>